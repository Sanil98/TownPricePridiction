import pandas as pd

def value(area):

	df =pd.read_csv(r'C:\Users\user\Downloads\Datasets\townprice.csv')
	df
	df.isnull().sum()
	from sklearn.linear_model import LinearRegression
	reg = LinearRegression()
	reg.fit(df[['area']],df.price)
	
    
	
	return reg.predict([[area]])