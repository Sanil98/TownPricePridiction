from django.shortcuts import render
from .townprice import value
import numpy as np



# Create your views here.

def First(request):
	return render(request,'first.html')

def Index(request):
	return render(request,'index.html')

def Prediction(request):
	if request.method == "POST":
		area = (request.POST['area'])

		my_var =value(area)

		return render(request,'prediction.html',{'my_var':my_var})
	return render(request,'prediction.html')
